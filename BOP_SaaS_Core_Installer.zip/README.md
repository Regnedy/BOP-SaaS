# BOP SaaS Core

Base deployment package for a Laravel multi-tenant modular platform.

Includes installation script.

Future modules:
- Companies
- Locations
- Modules
- POS
- CRM
- Inventory
- Mobile API
