#!/bin/bash
set -e

echo "Business Operating Platform - Laravel SaaS Core"

php artisan --version

composer install --no-interaction --prefer-dist --optimize-autoloader

if [ ! -f .env ]; then
    cp .env.example .env
fi

php artisan key:generate --force || true
php artisan migrate --force
php artisan optimize:clear

echo "Base installation completed."
