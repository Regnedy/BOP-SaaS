# BOP POS Android 007 COMPLETE

Paquete consolidado sin ZIP internos.

Incluye el bloque comercial:
- Login Real
- Dashboard Real
- POS Comercial
- Cobro
- Venta Completa
- Ticket

Preparado para integrarse al proyecto Android Studio 006.