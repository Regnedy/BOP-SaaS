# BOP POS Android 007 Complete

Bloque comercial POS:

007.1 Login Real
007.2 Dashboard Real
007.3 POS Comercial
007.4 Cobro
007.5 Venta Completa
007.6 Ticket e Impresión

Flujo:

Login
 -> Dashboard
 -> Productos
 -> Carrito
 -> Cobro
 -> Venta
 -> Ticket
 -> Sincronización