package com.bop.pos.presentation.dashboard

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable

@Composable
fun DashboardScreen() {
    Column(
        modifier = androidx.compose.ui.Modifier.padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "BOP POS",
            style = MaterialTheme.typography.headlineMedium
        )

        Button(onClick = {}) {
            Text("Nueva Venta")
        }

        Button(onClick = {}) {
            Text("Inventario")
        }

        Button(onClick = {}) {
            Text("Caja")
        }

        Button(onClick = {}) {
            Text("Reportes")
        }

        Button(onClick = {}) {
            Text("Configuración")
        }
    }
}