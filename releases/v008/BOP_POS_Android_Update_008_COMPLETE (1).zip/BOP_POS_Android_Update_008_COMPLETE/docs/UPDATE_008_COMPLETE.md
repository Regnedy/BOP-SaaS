# BOP POS Android 008 COMPLETE

Estado:

008.1 Configuración producción
008.2 Login real
008.3 Datos negocio
008.4 Venta real
008.5 Inventario real
008.6 Impresión Bluetooth
008.7 APK piloto

Flujo final:

Login
 -> Empresa
 -> Productos
 -> Venta
 -> Pago
 -> Inventario
 -> Ticket
 -> Sincronización

Siguiente etapa:
Pruebas piloto y conexión real con servidor.