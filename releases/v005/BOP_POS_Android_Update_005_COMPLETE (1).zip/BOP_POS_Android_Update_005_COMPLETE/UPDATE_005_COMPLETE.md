# BOP POS Android Update 005 Complete

Checkpoints:

005.1 Android Base
005.2 Login + Sanctum
005.3 Catalog Sync
005.4 POS Offline
005.5 Cashier
005.6 Sync Engine
005.7 Cloud Update

Objetivo:
Preparar la arquitectura completa de Android POS conectada al BOP SaaS.

Siguiente etapa:
Construcción de la aplicación Android funcional en Android Studio.