# BOP API Core 004.3 Sync Engine

Base de sincronización offline.

Incluye:
- Cola de eventos
- Modelo SyncQueue
- Controlador API