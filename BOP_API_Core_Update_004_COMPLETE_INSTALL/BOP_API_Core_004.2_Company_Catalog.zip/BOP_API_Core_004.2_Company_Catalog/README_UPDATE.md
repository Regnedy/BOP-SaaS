# BOP API Core 004.2

Base de API para datos iniciales del POS Android.