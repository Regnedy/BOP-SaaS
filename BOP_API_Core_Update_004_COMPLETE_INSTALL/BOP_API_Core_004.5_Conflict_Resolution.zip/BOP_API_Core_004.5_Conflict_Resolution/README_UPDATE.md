# BOP API Core 004.5

Agrega base para resolver conflictos de sincronización.