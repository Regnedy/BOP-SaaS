# BOP API Core 004.1

Primera capa API para Android.

Incluye:
- Autenticación
- Tokens
- Base de endpoints

Instalación:
Copiar archivos al proyecto Laravel.
Validar rutas con:

php artisan route:list --path=api