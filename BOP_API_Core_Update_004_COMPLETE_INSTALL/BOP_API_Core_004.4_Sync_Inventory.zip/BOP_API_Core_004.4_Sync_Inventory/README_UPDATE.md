# BOP API Core 004.4 Sync Inventory

Modulo de sincronizacion de inventario.

Base para POS offline multi sucursal.