BOP API Core 004.7
Motor inicial de actualizaciones cloud.