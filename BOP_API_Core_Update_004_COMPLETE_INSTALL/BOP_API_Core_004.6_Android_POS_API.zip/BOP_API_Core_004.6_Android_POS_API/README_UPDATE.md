BOP API Core 004.6
Base de integracion Android POS.