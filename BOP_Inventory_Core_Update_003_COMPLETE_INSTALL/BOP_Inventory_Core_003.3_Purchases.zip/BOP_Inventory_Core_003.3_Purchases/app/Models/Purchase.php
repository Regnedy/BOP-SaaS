<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Purchase extends Model
{
    protected $fillable = [
        'company_id','supplier_id','user_id',
        'subtotal','tax','total','status','date'
    ];

    public function items()
    {
        return $this->hasMany(PurchaseItem::class);
    }
}