<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Supplier extends Model
{
    protected $fillable = [
        'company_id','name','contact','phone','email','address','status'
    ];

    public function purchases()
    {
        return $this->hasMany(Purchase::class);
    }
}