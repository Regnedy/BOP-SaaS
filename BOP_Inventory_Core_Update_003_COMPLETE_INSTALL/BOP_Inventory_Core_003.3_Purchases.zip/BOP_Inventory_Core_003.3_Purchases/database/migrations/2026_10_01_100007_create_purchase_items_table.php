<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('purchase_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('purchase_id')
                ->constrained()
                ->cascadeOnDelete();
            $table->foreignId('inventory_item_id')
                ->constrained()
                ->cascadeOnDelete();
            $table->decimal('quantity',12,3);
            $table->decimal('cost',10,2);
            $table->decimal('subtotal',10,2);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('purchase_items');
    }
};