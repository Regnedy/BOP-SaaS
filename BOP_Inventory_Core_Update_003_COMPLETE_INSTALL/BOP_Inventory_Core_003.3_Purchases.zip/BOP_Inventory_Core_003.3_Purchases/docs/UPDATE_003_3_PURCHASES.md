# BOP Inventory Core - Update 003.3

## Compras y Proveedores

Objetivo:
Controlar entradas de materia prima y costos.

Agregado:

Tablas:
- suppliers
- purchases
- purchase_items

Modelos:
- Supplier.php
- Purchase.php
- PurchaseItem.php

Flujo:

Proveedor
 -> Compra
 -> Recepción
 -> Inventario


Instalación:

php artisan migrate


Siguiente checkpoint:
003.4 Mermas y Ajustes.