# BOP Inventory Core 003.3 Purchases

Agrega:
- Proveedores
- Compras
- Detalle de compras
- Base para actualizar costos