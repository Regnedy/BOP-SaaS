<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('profit_records', function (Blueprint $table) {
            $table->id();

            $table->foreignId('sale_item_id')
                ->constrained()
                ->cascadeOnDelete();

            $table->decimal('cost', 10, 2)
                ->default(0);

            $table->decimal('revenue', 10, 2)
                ->default(0);

            $table->decimal('profit', 10, 2)
                ->default(0);

            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('profit_records');
    }
};