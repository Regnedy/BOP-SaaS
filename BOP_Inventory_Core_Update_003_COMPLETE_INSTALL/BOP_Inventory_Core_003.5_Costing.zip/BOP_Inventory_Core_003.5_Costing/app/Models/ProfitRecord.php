<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProfitRecord extends Model
{
    protected $fillable = [
        'sale_item_id',
        'cost',
        'revenue',
        'profit'
    ];

    public function saleItem()
    {
        return $this->belongsTo(SaleItem::class);
    }
}