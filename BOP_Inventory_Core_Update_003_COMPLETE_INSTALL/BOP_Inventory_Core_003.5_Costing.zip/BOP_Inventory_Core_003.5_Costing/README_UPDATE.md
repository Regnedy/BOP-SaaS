# BOP Inventory Core 003.5 Costing

Agrega:
- Costos por producto
- Registros de utilidad
- Base para dashboards financieros