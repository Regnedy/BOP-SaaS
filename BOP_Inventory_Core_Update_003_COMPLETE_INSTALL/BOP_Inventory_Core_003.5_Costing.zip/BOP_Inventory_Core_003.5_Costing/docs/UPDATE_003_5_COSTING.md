# BOP Inventory Core - Update 003.5

## Costeo y Utilidad

Objetivo:
Calcular rentabilidad real de productos.

Agregado:

Tablas:
- product_costs
- profit_records

Modelos:
- ProductCost.php
- ProfitRecord.php

Permite conocer:

- costo de fabricación
- ingreso por venta
- utilidad
- margen


Ejemplo:

Nieve Pistache

Venta:
$65

Costo:
$17

Utilidad:
$48


Instalación:

php artisan migrate


Siguiente checkpoint:
003.6 Integración POS + Inventario.