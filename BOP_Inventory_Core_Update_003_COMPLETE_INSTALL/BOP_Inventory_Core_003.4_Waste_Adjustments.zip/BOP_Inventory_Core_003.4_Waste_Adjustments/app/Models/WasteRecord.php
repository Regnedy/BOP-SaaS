<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WasteRecord extends Model
{
    protected $fillable = [
        'inventory_item_id',
        'quantity',
        'reason',
        'description'
    ];

    public function inventoryItem()
    {
        return $this->belongsTo(InventoryItem::class);
    }
}