# BOP Inventory Core 003.4

Agrega:
- Mermas
- Ajustes manuales
- Control de pérdidas