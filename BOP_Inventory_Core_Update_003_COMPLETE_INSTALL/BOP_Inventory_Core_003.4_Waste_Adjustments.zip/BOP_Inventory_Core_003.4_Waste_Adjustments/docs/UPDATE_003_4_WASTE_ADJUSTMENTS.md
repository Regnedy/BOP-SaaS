# BOP Inventory Core - Update 003.4

## Mermas y Ajustes

Objetivo:
Controlar pérdidas y correcciones de inventario.

Agregado:

Tablas:
- waste_records
- inventory_adjustments

Modelos:
- WasteRecord.php
- InventoryAdjustment.php


Casos:

Caducidad
Producto dañado
Pérdida producción
Ajuste por conteo físico


Instalación:

php artisan migrate


Siguiente checkpoint:
003.5 Costeo y utilidad.