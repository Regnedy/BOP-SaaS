<?php

namespace App\Services;

class CostService
{
    public function calculateProfit($sale)
    {
        return 0;
    }
}