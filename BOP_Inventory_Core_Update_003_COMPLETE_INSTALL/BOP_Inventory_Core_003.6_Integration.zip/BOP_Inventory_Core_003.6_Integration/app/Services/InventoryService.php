<?php

namespace App\Services;

class InventoryService
{
    public function deductStock($recipe)
    {
        return true;
    }
}