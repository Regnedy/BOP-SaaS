<?php

namespace App\Services;

class RecipeService
{
    public function calculateCost($recipe)
    {
        return 0;
    }
}