# BOP Inventory Core 003.6

Cierre del módulo Inventory Core.

Incluye:
- Inventario
- Recetas
- Compras
- Mermas
- Costos
- Integración preparada