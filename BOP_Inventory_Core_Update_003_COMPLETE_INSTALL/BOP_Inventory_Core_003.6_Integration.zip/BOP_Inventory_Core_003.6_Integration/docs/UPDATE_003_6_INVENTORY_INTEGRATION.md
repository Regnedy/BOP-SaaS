# BOP Inventory Core - Update 003.6

## Integracion POS + Inventario

Objetivo:
Preparar la conexión entre ventas, recetas, inventario y costos.

Flujo:

Venta POS
 -> Producto
 -> Receta
 -> Consumo inventario
 -> Costo
 -> Utilidad

Servicios agregados:

- InventoryService
- RecipeService
- CostService

Estado:
Cierre del bloque Inventory Core.

Siguiente fase:
Dashboard y sincronización.