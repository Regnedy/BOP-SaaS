# Instalación SSH

cd proyecto

composer install

cp .env.example .env

php artisan key:generate

php artisan migrate --seed

php artisan storage:link