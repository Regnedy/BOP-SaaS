# Changelog

## v0.0.2 POS Core

Agregado:
- Catálogo
- Productos
- Variantes
- Ventas
- Pagos
- Caja
- Integración POS

Próximo:
Inventory Core.