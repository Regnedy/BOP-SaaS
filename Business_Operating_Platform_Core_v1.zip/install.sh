#!/bin/bash
echo 'Business Operating Platform Core'
echo 'Instalador preparado para proyecto Laravel existente'
echo 'Ejecutar dentro del proyecto Laravel:'
echo 'composer install'
echo 'php artisan migrate'
echo 'php artisan db:seed'
