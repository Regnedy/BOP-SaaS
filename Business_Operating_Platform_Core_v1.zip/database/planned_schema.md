Tablas núcleo:

companies
- id
- name
- industry
- settings
- status

locations
- company_id
- name

modules
- name
- slug

company_modules
- company_id
- module_id
- active

devices
- company_id
- device_uuid

sync_queue
- device_id
- payload
- status

cash_sessions
- location_id
- user_id
- opening_amount
- closing_amount
