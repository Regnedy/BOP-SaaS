# Business Operating Platform Core v1

Arquitectura base SaaS multiempresa para Laravel.

Objetivo:
- Multiempresa
- Módulos activables
- Roles y permisos
- Puntos de venta
- API preparada para Android/iOS
- Arquitectura offline-first futura

Módulos previstos:
- Core SaaS
- POS
- Inventario
- CRM
- Agenda
- Reportes
- Backups

Este paquete es una base de arquitectura y documentación.
