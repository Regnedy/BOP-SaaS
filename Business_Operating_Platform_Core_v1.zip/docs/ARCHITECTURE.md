# Arquitectura

CORE
- Companies
- Users
- Roles
- Permissions
- Modules
- Settings
- Audit Logs
- Backups

Business Modules:
- POS
- Inventory
- CRM
- Appointments

Mobile:
Android/iOS consume Laravel API.
La aplicación móvil recibe configuración dinámica por empresa.
